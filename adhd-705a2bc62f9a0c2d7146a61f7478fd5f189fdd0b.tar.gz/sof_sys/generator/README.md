Use `cargo run` to generate rust bindings at sof_sys/src/bindings.rs
